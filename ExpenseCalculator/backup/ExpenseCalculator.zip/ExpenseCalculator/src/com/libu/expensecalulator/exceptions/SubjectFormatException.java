package com.libu.expensecalulator.exceptions;

public class SubjectFormatException extends Exception {

}
