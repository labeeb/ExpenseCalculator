package com.libu.expensecalulator.exceptions;

public class DateNotInTheCurrentMonth extends Exception{

}
