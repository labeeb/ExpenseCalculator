package com.libu.expensecalulator.db;

public class Type {

}
